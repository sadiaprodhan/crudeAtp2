﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;


namespace MvcRepo.Models
{
    public class PersonRepo
    {
        DataAccess data;
        SqlDataReader sqldata;
        public PersonRepo()
        { this.data = new DataAccess(); }

        public List<Person> getAll()
        {
            string sql = "Select * from Persons";
            SqlDataReader sqldata = this.data.getData(sql);
            List<Person> personlist = new List<Person>();
            while (sqldata.Read())
            {
                Person p = new Person();
                p.Id = Convert.ToInt32(sqldata["Id"]);
                p.Name = sqldata["Name"].ToString();
                p.Email = sqldata["Email"].ToString();
                personlist.Add(p);
            }
            return personlist;
        }
        public Person GetPerson(int id)
        {
            string sql= "Select * from Persons where Id="+id;
            this.sqldata = this.data.getData(sql);
            Person p = new Person();
            while (sqldata.Read())
            {
                p.Name = sqldata["Name"].ToString();
                p.Email = sqldata["Email"].ToString();
            }
            return p;
        }
        public int AddPerson(string name, string email)
        {
            string sql= "Insert into Persons values('"+name+"','"+email+"')";
            int count= this.data.Operation(sql);
            return count;

         
    
        }
        

    }
}