﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace MvcRepo.Models
{
    public class DataAccess
    {
        SqlConnection connection;
      

        public DataAccess ()
        {
            this.connection = new SqlConnection(ConfigurationManager.ConnectionStrings["PDB"].ConnectionString);
            connection.Open();
       }
        public SqlDataReader getData(string sql)
        { SqlCommand command = new SqlCommand(sql, connection);
        return command.ExecuteReader();

        }
        public int Operation(string sql)
        { SqlCommand command = new SqlCommand(sql, connection);
        return command.ExecuteNonQuery();
        }

       
    }
}