﻿using MvcRepo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcRepo.Controllers
{
    public class PersonController : Controller
    {
        //
        // GET: /Person/

        public ActionResult Index()
        {
            PersonRepo repo = new PersonRepo(); 
            return View(repo.getAll());
        }
        public ActionResult Details(int id)
        {
            PersonRepo repo = new PersonRepo();
            return View(repo.GetPerson(id));
        
        }
        [HttpGet]
        public ActionResult Create()
        {
           
            return View();

        
        }
        [HttpPost]
        public ActionResult Create(string name, string email)
        {
            PersonRepo repo = new PersonRepo();
            int count= repo.AddPerson(name,email);
            if (count >= 1)
            { return Content("Succesful"); }
            else
            { return Content("Unsuccesful"); }
           


        }
    }
}
